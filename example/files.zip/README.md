# 🏗️ Terraform — Infraestructura como Código
## Arquitectura: ECS Fargate + RDS + S3 + CloudFront

Este proyecto reproduce en Terraform la arquitectura que montaste manualmente.

---

## 📐 Arquitectura

```
Internet
   │
   ├─── CloudFront ──── S3 (Frontend Angular)
   │
   └─── IP Pública ──── ECS Fargate (.NET API)
                              │
                         VPC 10.0.0.0/16
                              │
                    ┌─────────┴─────────┐
               Subnets Públicas    Subnets Privadas
               (ECS Tasks)        (RDS PostgreSQL)
                              │
                         Secrets Manager
                         (connection string, JWT)
```

---

## 📂 Estructura del Proyecto

```
terraform-gestion-proyectos/
├── main.tf                    ← Orquestador (llama a todos los módulos)
├── variables.tf               ← Variables del proyecto raíz
├── outputs.tf                 ← Valores importantes post-apply
├── terraform.tfvars.example   ← Plantilla de configuración (¡no subir al repo!)
├── .gitignore
└── modules/
    ├── networking/            ← VPC, Subnets, IGW, Route Tables
    ├── iam/                   ← Roles IAM para ECS
    ├── secrets/               ← AWS Secrets Manager
    ├── ecr/                   ← Registro de imágenes Docker
    ├── rds/                   ← PostgreSQL en RDS
    ├── s3-cloudfront/         ← Frontend + CloudFront + bucket de archivos
    └── ecs/                   ← Cluster, Task Definition, Service
```

---

## 🚀 Uso Paso a Paso

### 1. Instalar Terraform
```bash
# macOS
brew install terraform

# Windows (Chocolatey)
choco install terraform

# Verificar
terraform -version   # >= 1.6
```

### 2. Configurar variables
```bash
cp terraform.tfvars.example terraform.tfvars
# Edita terraform.tfvars con tus valores reales
```

### 3. Inicializar Terraform
```bash
terraform init
```
Esto descarga el provider de AWS y prepara el proyecto.

### 4. Ver el plan
```bash
terraform plan
```
Terraform te muestra EXACTAMENTE qué va a crear/modificar/destruir.
**Léelo antes de aplicar.** Es tu diff de infraestructura.

### 5. Aplicar
```bash
terraform apply
```
Escribe `yes` cuando te lo pida. Puede tardar 5-10 minutos (RDS tarda más).

### 6. Ver los outputs
```bash
terraform output
```
Verás las URLs de CloudFront, el endpoint de RDS, etc.

---

## ⚠️ Orden Importante: Primer Deploy

Hay una dependencia circular: `allowed_origins` (CORS del backend)
necesita la URL de CloudFront, pero CloudFront se crea con Terraform.

**Solución — Dos fases:**

**Fase 1:** Aplicar todo con `allowed_origins = "*"` temporal
```bash
terraform apply
terraform output cloudfront_domain   # copia este valor
```

**Fase 2:** Actualizar `terraform.tfvars` con la URL real de CloudFront
```hcl
allowed_origins = "https://XXXXXXXXXXXX.cloudfront.net"
```
```bash
terraform apply   # solo actualiza el ECS service (rápido)
```

---

## 🔗 Conectar con tus Pipelines de GitHub Actions

Después del `terraform apply`, actualiza los **GitHub Secrets** de tu repo:

| Secret | Dónde obtenerlo |
|--------|----------------|
| `ECR_REPOSITORY` | `terraform output ecr_repository_url` |
| `ECS_CLUSTER` | `terraform output ecs_cluster_name` |
| `ECS_SERVICE` | `terraform output ecs_service_name` |
| `TASK_FAMILY` | `gestion-proyectos-dev-task` |
| `CONTAINER_NAME` | `gestion-proyectos-container` |
| `AWS_ACCESS_KEY_ID` | Tu IAM user |
| `AWS_SECRET_ACCESS_KEY` | Tu IAM user |

Para el frontend (`deploy-front-s3.yml`):
- `S3_BUCKET` → `terraform output s3_frontend_bucket`

Y puedes activar la invalidación de CloudFront en el pipeline añadiendo:
```yaml
- name: Invalidar cache CloudFront
  run: |
    aws cloudfront create-invalidation \
      --distribution-id ${{ secrets.CLOUDFRONT_DISTRIBUTION_ID }} \
      --paths "/*"
```

---

## 💡 Conceptos de Terraform que aplica este proyecto

### Resources
Cada bloque `resource` crea un elemento en AWS:
```hcl
resource "aws_ecs_cluster" "main" {   # tipo y nombre lógico
  name = "mi-cluster"                  # configuración
}
```

### Variables y Outputs
- `variables.tf` → parámetros de entrada (como argumentos de una función)
- `outputs.tf` → valores de salida para usar en otros lugares
- `terraform.tfvars` → los valores concretos de tus variables

### State
Terraform guarda el estado en `terraform.tfstate`. Este archivo mapea
tus recursos de código con los recursos reales en AWS.
**Nunca lo edites manualmente.** Para equipos, guárdalo en S3 (ver main.tf).

### Modules
Los módulos son carpetas con su propio `main.tf`, `variables.tf` y `outputs.tf`.
Son como funciones reutilizables de tu infraestructura.

```hcl
module "ecs" {
  source       = "./modules/ecs"
  project_name = var.project_name    # le pasas parámetros
  vpc_id       = module.networking.vpc_id   # y usas outputs de otros módulos
}
```

---

## 🧹 Limpiar Todo
```bash
# ⚠️ DESTRUYE todos los recursos de AWS (para no pagar)
terraform destroy
```

---

## 💰 Costos Estimados

| Recurso | Costo aprox. |
|---------|-------------|
| ECS Fargate (512 CPU / 1GB) | ~$0.049/hora ≈ $8/mes (8h/día) |
| RDS db.t3.micro | ~$0.017/hora ≈ $12/mes (siempre on) |
| S3 frontend + archivos | < $1/mes |
| CloudFront | Primeros 1TB gratis |
| ECR | 500MB gratis primer año |
| Secrets Manager | ~$0.40/secret/mes |
| **Total estimado** | **~$20-35/mes** |

**Para ahorrar:** usa `terraform apply -var="task_cpu=256" -var="task_memory=512"` en dev.
