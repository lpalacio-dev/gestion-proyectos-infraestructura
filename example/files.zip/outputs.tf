###############################################################
# OUTPUTS.TF — Valores importantes después del apply
###############################################################

output "ecr_repository_url" {
  description = "URL del repositorio ECR (úsala en tu pipeline)"
  value       = module.ecr.repository_url
}

output "ecs_cluster_name" {
  description = "Nombre del cluster ECS"
  value       = module.ecs.cluster_name
}

output "ecs_service_name" {
  description = "Nombre del servicio ECS"
  value       = module.ecs.service_name
}

output "rds_endpoint" {
  description = "Endpoint de la base de datos RDS"
  value       = module.rds.endpoint
}

output "cloudfront_domain" {
  description = "Dominio de CloudFront para el frontend"
  value       = module.s3_cloudfront.cloudfront_domain
}

output "cloudfront_distribution_id" {
  description = "ID de la distribución CloudFront (para invalidaciones en el pipeline)"
  value       = module.s3_cloudfront.cloudfront_distribution_id
}

output "s3_frontend_bucket" {
  description = "Nombre del bucket S3 del frontend"
  value       = module.s3_cloudfront.frontend_bucket_name
}

output "s3_files_bucket" {
  description = "Nombre del bucket S3 de archivos"
  value       = module.s3_cloudfront.files_bucket_name
}

output "vpc_id" {
  description = "ID de la VPC creada"
  value       = module.networking.vpc_id
}
