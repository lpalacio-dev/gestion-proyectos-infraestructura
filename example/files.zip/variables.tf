###############################################################
# VARIABLES.TF — Configuración centralizada del proyecto
###############################################################

# ─── GLOBALES ────────────────────────────────────────────────
variable "aws_region" {
  description = "Región de AWS donde se desplegará todo"
  type        = string
  default     = "us-east-2"
}

variable "aws_account_id" {
  description = "Tu AWS Account ID (12 dígitos)"
  type        = string
}

variable "project_name" {
  description = "Nombre base del proyecto (se usa en todos los recursos)"
  type        = string
  default     = "gestion-proyectos"
}

variable "environment" {
  description = "Ambiente de despliegue"
  type        = string
  default     = "dev"
  validation {
    condition     = contains(["dev", "prod"], var.environment)
    error_message = "El ambiente debe ser 'dev' o 'prod'."
  }
}

# ─── NETWORKING ──────────────────────────────────────────────
variable "vpc_cidr" {
  description = "CIDR block para la VPC"
  type        = string
  default     = "10.0.0.0/16"
}

# ─── ECS / BACKEND ───────────────────────────────────────────
variable "container_port" {
  description = "Puerto en el que escucha el contenedor .NET"
  type        = number
  default     = 8080
}

variable "task_cpu" {
  description = "CPU units para la task de Fargate (256, 512, 1024...)"
  type        = number
  default     = 512
}

variable "task_memory" {
  description = "Memoria en MB para la task de Fargate"
  type        = number
  default     = 1024
}

variable "allowed_origins" {
  description = "Orígenes permitidos para CORS (URL del frontend)"
  type        = string
  default     = "https://tu-distribucion.cloudfront.net"
}

# ─── RDS ─────────────────────────────────────────────────────
variable "db_name" {
  description = "Nombre de la base de datos PostgreSQL"
  type        = string
  default     = "gestion_proyectos"
}

variable "db_username" {
  description = "Usuario administrador de la BD"
  type        = string
  default     = "admindb"
}

variable "db_password" {
  description = "Contraseña de la BD (maneja esto con cuidado)"
  type        = string
  sensitive   = true
}

variable "db_instance_class" {
  description = "Instancia de RDS (db.t3.micro está en free tier)"
  type        = string
  default     = "db.t3.micro"
}

# ─── S3 ──────────────────────────────────────────────────────
variable "s3_frontend_bucket_name" {
  description = "Nombre del bucket S3 para el frontend Angular"
  type        = string
  default     = "gestion-proyectos-front"
}

variable "s3_files_bucket_name" {
  description = "Nombre del bucket S3 para archivos del backend (profile images, etc.)"
  type        = string
  default     = "gestion-proyectos-files"
}

# ─── SECRETS (se guardan en Secrets Manager) ─────────────────
variable "db_connection_string" {
  description = "Connection string completo para PostgreSQL"
  type        = string
  sensitive   = true
}

variable "jwt_key" {
  description = "Clave secreta JWT (mínimo 32 caracteres)"
  type        = string
  sensitive   = true
}

variable "jwt_issuer" {
  description = "JWT Issuer URL"
  type        = string
  default     = "https://tu-api.com"
}

variable "jwt_audience" {
  description = "JWT Audience URL"
  type        = string
  default     = "https://tu-api.com"
}
