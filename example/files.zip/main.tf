###############################################################
# MAIN.TF — Orquesta todos los módulos de la arquitectura
###############################################################

terraform {
  required_version = ">= 1.6"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }

  # 💡 Cuando quieras guardar el state en S3 (recomendado), descomenta:
  # backend "s3" {
  #   bucket = "mi-terraform-state-bucket"
  #   key    = "gestion-proyectos/terraform.tfstate"
  #   region = "us-east-2"
  # }
}

provider "aws" {
  region = var.aws_region
}

###############################################################
# NETWORKING — VPC, Subnets, IGW, Route Tables
###############################################################
module "networking" {
  source = "./modules/networking"

  project_name = var.project_name
  environment  = var.environment
  vpc_cidr     = var.vpc_cidr
  aws_region   = var.aws_region
}

###############################################################
# IAM — Roles para ECS Task Execution y Task Role
###############################################################
module "iam" {
  source = "./modules/iam"

  project_name = var.project_name
  environment  = var.environment
}

###############################################################
# SECRETS MANAGER — Connection string y JWT Key
###############################################################
module "secrets" {
  source = "./modules/secrets"

  project_name          = var.project_name
  environment           = var.environment
  db_connection_string  = var.db_connection_string
  jwt_key               = var.jwt_key
  jwt_issuer            = var.jwt_issuer
  jwt_audience          = var.jwt_audience
  s3_bucket_name        = var.s3_files_bucket_name
}

###############################################################
# ECR — Registro de imágenes Docker
###############################################################
module "ecr" {
  source = "./modules/ecr"

  project_name = var.project_name
  environment  = var.environment
}

###############################################################
# RDS — Base de datos PostgreSQL
###############################################################
module "rds" {
  source = "./modules/rds"

  project_name    = var.project_name
  environment     = var.environment
  vpc_id          = module.networking.vpc_id
  subnet_ids      = module.networking.private_subnet_ids
  ecs_sg_id       = module.ecs.ecs_security_group_id
  db_name         = var.db_name
  db_username     = var.db_username
  db_password     = var.db_password
  db_instance     = var.db_instance_class
}

###############################################################
# S3 + CloudFront — Frontend Angular
###############################################################
module "s3_cloudfront" {
  source = "./modules/s3-cloudfront"

  project_name = var.project_name
  environment  = var.environment
  s3_bucket_name_frontend = var.s3_frontend_bucket_name
  s3_bucket_name_files    = var.s3_files_bucket_name
}

###############################################################
# ECS Fargate — Backend .NET
###############################################################
module "ecs" {
  source = "./modules/ecs"

  project_name            = var.project_name
  environment             = var.environment
  aws_region              = var.aws_region
  aws_account_id          = var.aws_account_id
  vpc_id                  = module.networking.vpc_id
  public_subnet_ids       = module.networking.public_subnet_ids
  ecr_repository_url      = module.ecr.repository_url
  execution_role_arn      = module.iam.ecs_execution_role_arn
  task_role_arn           = module.iam.ecs_task_role_arn
  container_port          = var.container_port
  task_cpu                = var.task_cpu
  task_memory             = var.task_memory
  db_secret_arn           = module.secrets.db_secret_arn
  jwt_secret_arn          = module.secrets.jwt_secret_arn
  s3_bucket_name          = var.s3_files_bucket_name
  s3_secret_arn           = module.secrets.s3_secret_arn
  allowed_origins         = var.allowed_origins
}
