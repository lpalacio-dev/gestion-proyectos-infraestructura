###############################################################
# MODULE: ecs
# ECS Fargate: Cluster, Task Definition, Service
# Con Security Groups y CloudWatch Logs
###############################################################

locals {
  name           = "${var.project_name}-${var.environment}"
  container_name = "${var.project_name}-container"
}

# ─── CLOUDWATCH LOG GROUP ────────────────────────────────────
resource "aws_cloudwatch_log_group" "ecs" {
  name              = "/ecs/${local.name}"
  retention_in_days = 30   # ajusta según necesidad (0 = nunca expiran)

  tags = { Name = "${local.name}-logs" }
}

# ─── SECURITY GROUP para ECS Tasks ───────────────────────────
resource "aws_security_group" "ecs" {
  name        = "${local.name}-ecs-sg"
  description = "Security group para las tasks de ECS Fargate"
  vpc_id      = var.vpc_id

  # Tráfico entrante al puerto de la app
  ingress {
    from_port   = var.container_port
    to_port     = var.container_port
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]   # Restringe a ALB security group en producción
    description = "Puerto de la aplicación .NET"
  }

  # Todo el tráfico saliente (necesario para ECR, Secrets Manager, RDS, etc.)
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = { Name = "${local.name}-ecs-sg" }
}

# ─── ECS CLUSTER ─────────────────────────────────────────────
resource "aws_ecs_cluster" "main" {
  name = "${local.name}-cluster"

  setting {
    name  = "containerInsights"
    value = "enabled"   # métricas detalladas en CloudWatch
  }

  tags = { Name = "${local.name}-cluster" }
}

# Capacidad Fargate + Fargate Spot (spot = más barato pero interrumpible)
resource "aws_ecs_cluster_capacity_providers" "main" {
  cluster_name       = aws_ecs_cluster.main.name
  capacity_providers = ["FARGATE", "FARGATE_SPOT"]

  default_capacity_provider_strategy {
    base              = 1
    weight            = 100
    capacity_provider = "FARGATE"
  }
}

# ─── ECS TASK DEFINITION ─────────────────────────────────────
resource "aws_ecs_task_definition" "backend" {
  family                   = "${local.name}-task"
  network_mode             = "awsvpc"
  requires_compatibilities = ["FARGATE"]
  cpu                      = tostring(var.task_cpu)
  memory                   = tostring(var.task_memory)
  execution_role_arn       = var.execution_role_arn
  task_role_arn            = var.task_role_arn

  container_definitions = jsonencode([{
    name      = local.container_name
    image     = "${var.ecr_repository_url}:latest"
    essential = true

    portMappings = [{
      containerPort = var.container_port
      protocol      = "tcp"
    }]

    # Variables de entorno no secretas
    environment = [
      { name = "ASPNETCORE_ENVIRONMENT", value = "Production" },
      { name = "ASPNETCORE_URLS",        value = "http://+:${var.container_port}" },
      { name = "CORS__AllowedOrigins",   value = var.allowed_origins }
    ]

    # Secretos inyectados desde Secrets Manager
    # Tu app los lee como env vars (builder.Configuration.AddEnvironmentVariables())
    secrets = [
      {
        name      = "ConnectionStrings__PostgreSQLConnection"
        valueFrom = var.db_secret_arn
      },
      {
        name      = "Jwt__Key"
        valueFrom = var.jwt_secret_arn
      },
      {
        name      = "S3_BUCKET_NAME"
        valueFrom = var.s3_secret_arn
      }
    ]

    logConfiguration = {
      logDriver = "awslogs"
      options = {
        "awslogs-group"         = aws_cloudwatch_log_group.ecs.name
        "awslogs-region"        = var.aws_region
        "awslogs-stream-prefix" = "backend"
      }
    }

    healthCheck = {
      command     = ["CMD-SHELL", "curl -f http://localhost:${var.container_port}/health || exit 1"]
      interval    = 30
      timeout     = 5
      retries     = 3
      startPeriod = 60   # da tiempo al .NET app de inicializar
    }
  }])

  tags = { Name = "${local.name}-task-def" }
}

# ─── ECS SERVICE ─────────────────────────────────────────────
resource "aws_ecs_service" "backend" {
  name            = "${local.name}-service"
  cluster         = aws_ecs_cluster.main.id
  task_definition = aws_ecs_task_definition.backend.arn
  desired_count   = 1   # cambia a 2+ en producción

  # Fargate launch type
  launch_type = "FARGATE"

  network_configuration {
    subnets          = var.public_subnet_ids
    security_groups  = [aws_security_group.ecs.id]
    assign_public_ip = true   # necesario en subnets públicas sin NAT GW
  }

  # Para deployments sin downtime (reemplaza tasks gradualmente)
  deployment_minimum_healthy_percent = 100
  deployment_maximum_percent         = 200

  # Esperar a que el health check pase antes de considerar el deploy exitoso
  health_check_grace_period_seconds = 60

  # Importante: ignora cambios en task_definition y desired_count
  # para que GitHub Actions (tu pipeline) controle las actualizaciones de imagen
  lifecycle {
    ignore_changes = [task_definition, desired_count]
  }

  tags = { Name = "${local.name}-service" }
}
