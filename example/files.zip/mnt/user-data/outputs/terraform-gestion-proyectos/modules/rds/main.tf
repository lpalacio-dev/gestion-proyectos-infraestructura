###############################################################
# MODULE: rds
# Base de datos PostgreSQL en AWS RDS
###############################################################

locals {
  name = "${var.project_name}-${var.environment}"
}

# ─── SUBNET GROUP (RDS requiere al menos 2 AZs) ──────────────
resource "aws_db_subnet_group" "main" {
  name       = "${local.name}-db-subnet-group"
  subnet_ids = var.subnet_ids

  tags = { Name = "${local.name}-db-subnet-group" }
}

# ─── SECURITY GROUP para RDS ─────────────────────────────────
resource "aws_security_group" "rds" {
  name        = "${local.name}-rds-sg"
  description = "Permite tráfico PostgreSQL solo desde ECS"
  vpc_id      = var.vpc_id

  # Solo acepta conexiones del security group de ECS
  ingress {
    from_port       = 5432
    to_port         = 5432
    protocol        = "tcp"
    security_groups = [var.ecs_sg_id]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = { Name = "${local.name}-rds-sg" }
}

# ─── RDS INSTANCE ────────────────────────────────────────────
resource "aws_db_instance" "postgres" {
  identifier        = "${local.name}-postgres"
  engine            = "postgres"
  engine_version    = "15.4"
  instance_class    = var.db_instance       # db.t3.micro = free tier
  allocated_storage = 20                    # GB mínimo
  storage_type      = "gp2"

  db_name  = var.db_name
  username = var.db_username
  password = var.db_password

  db_subnet_group_name   = aws_db_subnet_group.main.name
  vpc_security_group_ids = [aws_security_group.rds.id]

  # Importante: false = no es accesible desde internet (más seguro)
  publicly_accessible = false

  # Backup automático
  backup_retention_period = 7       # días
  backup_window           = "03:00-04:00"
  maintenance_window      = "Mon:04:00-Mon:05:00"

  # Para desarrollo: skip final snapshot al destruir
  skip_final_snapshot = true
  deletion_protection = false       # cambia a true en producción

  multi_az = false   # true en producción para alta disponibilidad

  tags = { Name = "${local.name}-postgres" }
}
