###############################################################
# MODULE: ecr
# Registro de imágenes Docker para el backend .NET
###############################################################

locals {
  name = "${var.project_name}-${var.environment}"
}

resource "aws_ecr_repository" "backend" {
  name                 = "${local.name}-backend"
  image_tag_mutability = "MUTABLE"   # permite sobreescribir tags (como :latest)

  image_scanning_configuration {
    scan_on_push = true   # buena práctica de seguridad
  }

  tags = { Name = "${local.name}-ecr" }
}

# Política para limpiar imágenes viejas automáticamente (ahorra espacio)
resource "aws_ecr_lifecycle_policy" "backend" {
  repository = aws_ecr_repository.backend.name

  policy = jsonencode({
    rules = [{
      rulePriority = 1
      description  = "Mantener solo las últimas 10 imágenes"
      selection = {
        tagStatus   = "any"
        countType   = "imageCountMoreThan"
        countNumber = 10
      }
      action = { type = "expire" }
    }]
  })
}
