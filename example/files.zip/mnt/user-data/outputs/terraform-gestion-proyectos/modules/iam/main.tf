###############################################################
# MODULE: iam
# Crea los roles IAM que necesita ECS Fargate
###############################################################

locals {
  name = "${var.project_name}-${var.environment}"
}

# ─── ECS TASK EXECUTION ROLE ─────────────────────────────────
# Permite a Fargate descargar la imagen de ECR y escribir logs
resource "aws_iam_role" "ecs_execution" {
  name = "${local.name}-ecs-execution-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "ecs-tasks.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })

  tags = { Name = "${local.name}-ecs-execution-role" }
}

resource "aws_iam_role_policy_attachment" "ecs_execution_policy" {
  role       = aws_iam_role.ecs_execution.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy"
}

# Permite leer secrets de Secrets Manager (para connection string y JWT)
resource "aws_iam_role_policy" "ecs_secrets_policy" {
  name = "${local.name}-ecs-secrets-policy"
  role = aws_iam_role.ecs_execution.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = ["secretsmanager:GetSecretValue"]
      Resource = "*"   # Se puede restringir a los ARNs específicos en producción
    }]
  })
}

# ─── ECS TASK ROLE ───────────────────────────────────────────
# Permisos que tiene tu APLICACIÓN en ejecución (S3, Lambda, etc.)
resource "aws_iam_role" "ecs_task" {
  name = "${local.name}-ecs-task-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "ecs-tasks.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })

  tags = { Name = "${local.name}-ecs-task-role" }
}

# Tu backend usa S3 (subir/descargar imágenes de perfil, archivos, etc.)
resource "aws_iam_role_policy" "ecs_task_s3" {
  name = "${local.name}-ecs-task-s3"
  role = aws_iam_role.ecs_task.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Action = [
        "s3:PutObject",
        "s3:GetObject",
        "s3:DeleteObject",
        "s3:HeadObject"
      ]
      Resource = "arn:aws:s3:::*/*"   # Restringe al bucket específico en producción
    }]
  })
}

# Tu backend también usa Lambda (IAmazonLambda en Program.cs)
resource "aws_iam_role_policy" "ecs_task_lambda" {
  name = "${local.name}-ecs-task-lambda"
  role = aws_iam_role.ecs_task.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = ["lambda:InvokeFunction"]
      Resource = "*"
    }]
  })
}
