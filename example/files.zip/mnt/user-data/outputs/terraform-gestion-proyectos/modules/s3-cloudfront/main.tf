###############################################################
# MODULE: s3-cloudfront
# Frontend Angular en S3 + CloudFront
# Bucket de archivos privados (imágenes de perfil, adjuntos)
###############################################################

locals {
  name = "${var.project_name}-${var.environment}"
}

# ─── BUCKET FRONTEND (Angular SPA) ───────────────────────────
resource "aws_s3_bucket" "frontend" {
  bucket = var.s3_bucket_name_frontend
  tags   = { Name = "${local.name}-frontend" }
}

# Bloquear acceso público directo (CloudFront será el único acceso)
resource "aws_s3_bucket_public_access_block" "frontend" {
  bucket                  = aws_s3_bucket.frontend.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

# Habilitar versionado (permite rollback de deployments)
resource "aws_s3_bucket_versioning" "frontend" {
  bucket = aws_s3_bucket.frontend.id
  versioning_configuration { status = "Enabled" }
}

# ─── CLOUDFRONT ORIGIN ACCESS CONTROL ────────────────────────
resource "aws_cloudfront_origin_access_control" "frontend" {
  name                              = "${local.name}-oac"
  description                       = "OAC para ${local.name} frontend"
  origin_access_control_origin_type = "s3"
  signing_behavior                  = "always"
  signing_protocol                  = "sigv4"
}

# ─── POLÍTICA S3 que solo permite acceso desde CloudFront ────
resource "aws_s3_bucket_policy" "frontend" {
  bucket = aws_s3_bucket.frontend.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Sid       = "AllowCloudFrontAccess"
      Effect    = "Allow"
      Principal = { Service = "cloudfront.amazonaws.com" }
      Action    = "s3:GetObject"
      Resource  = "${aws_s3_bucket.frontend.arn}/*"
      Condition = {
        StringEquals = {
          "AWS:SourceArn" = aws_cloudfront_distribution.frontend.arn
        }
      }
    }]
  })
}

# ─── CLOUDFRONT DISTRIBUTION ─────────────────────────────────
resource "aws_cloudfront_distribution" "frontend" {
  enabled             = true
  is_ipv6_enabled     = true
  comment             = "${local.name} frontend"
  default_root_object = "index.html"

  origin {
    domain_name              = aws_s3_bucket.frontend.bucket_regional_domain_name
    origin_id                = "S3-${aws_s3_bucket.frontend.id}"
    origin_access_control_id = aws_cloudfront_origin_access_control.frontend.id
  }

  default_cache_behavior {
    allowed_methods        = ["GET", "HEAD", "OPTIONS"]
    cached_methods         = ["GET", "HEAD"]
    target_origin_id       = "S3-${aws_s3_bucket.frontend.id}"
    viewer_protocol_policy = "redirect-to-https"
    compress               = true

    forwarded_values {
      query_string = false
      cookies { forward = "none" }
    }

    min_ttl     = 0
    default_ttl = 3600
    max_ttl     = 86400
  }

  # Importante para Angular Router (HTML5 mode): redirigir 404 a index.html
  custom_error_response {
    error_code            = 403
    response_code         = 200
    response_page_path    = "/index.html"
  }

  custom_error_response {
    error_code            = 404
    response_code         = 200
    response_page_path    = "/index.html"
  }

  restrictions {
    geo_restriction { restriction_type = "none" }
  }

  viewer_certificate {
    cloudfront_default_certificate = true   # usa *.cloudfront.net (gratis)
    # Para dominio propio, configura aquí un ACM certificate
  }

  tags = { Name = "${local.name}-cloudfront" }
}

# ─── BUCKET DE ARCHIVOS PRIVADOS (imágenes de perfil, etc.) ──
resource "aws_s3_bucket" "files" {
  bucket = var.s3_bucket_name_files
  tags   = { Name = "${local.name}-files" }
}

resource "aws_s3_bucket_public_access_block" "files" {
  bucket                  = aws_s3_bucket.files.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

# Política de ciclo de vida: limpiar archivos temporales después de 90 días
resource "aws_s3_bucket_lifecycle_configuration" "files" {
  bucket = aws_s3_bucket.files.id

  rule {
    id     = "cleanup-temp-files"
    status = "Enabled"

    filter { prefix = "temp/" }

    expiration { days = 7 }
  }
}

# CORS para que el frontend pueda subir archivos directamente a S3
resource "aws_s3_bucket_cors_configuration" "files" {
  bucket = aws_s3_bucket.files.id

  cors_rule {
    allowed_headers = ["*"]
    allowed_methods = ["GET", "PUT", "POST", "DELETE", "HEAD"]
    allowed_origins = ["*"]   # Restringe a tu dominio en producción
    max_age_seconds = 3000
  }
}
