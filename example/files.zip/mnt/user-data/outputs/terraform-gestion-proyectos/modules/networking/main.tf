###############################################################
# MODULE: networking
# Crea: VPC, 2 subnets públicas, 2 subnets privadas, IGW, NAT GW
###############################################################

locals {
  name = "${var.project_name}-${var.environment}"

  # AZs disponibles en la región
  azs = ["${var.aws_region}a", "${var.aws_region}b"]

  public_subnets  = ["10.0.1.0/24", "10.0.2.0/24"]
  private_subnets = ["10.0.11.0/24", "10.0.12.0/24"]
}

# ─── VPC ─────────────────────────────────────────────────────
resource "aws_vpc" "main" {
  cidr_block           = var.vpc_cidr
  enable_dns_support   = true
  enable_dns_hostnames = true   # necesario para que RDS tenga hostname

  tags = {
    Name        = "${local.name}-vpc"
    Environment = var.environment
  }
}

# ─── INTERNET GATEWAY ────────────────────────────────────────
resource "aws_internet_gateway" "main" {
  vpc_id = aws_vpc.main.id

  tags = {
    Name = "${local.name}-igw"
  }
}

# ─── SUBNETS PÚBLICAS (ECS Fargate con IP pública) ───────────
resource "aws_subnet" "public" {
  count = length(local.public_subnets)

  vpc_id                  = aws_vpc.main.id
  cidr_block              = local.public_subnets[count.index]
  availability_zone       = local.azs[count.index]
  map_public_ip_on_launch = true

  tags = {
    Name = "${local.name}-public-${count.index + 1}"
    Type = "public"
  }
}

# ─── SUBNETS PRIVADAS (RDS) ──────────────────────────────────
resource "aws_subnet" "private" {
  count = length(local.private_subnets)

  vpc_id            = aws_vpc.main.id
  cidr_block        = local.private_subnets[count.index]
  availability_zone = local.azs[count.index]

  tags = {
    Name = "${local.name}-private-${count.index + 1}"
    Type = "private"
  }
}

# ─── ROUTE TABLE PÚBLICA ─────────────────────────────────────
resource "aws_route_table" "public" {
  vpc_id = aws_vpc.main.id

  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.main.id
  }

  tags = {
    Name = "${local.name}-rt-public"
  }
}

resource "aws_route_table_association" "public" {
  count          = length(aws_subnet.public)
  subnet_id      = aws_subnet.public[count.index].id
  route_table_id = aws_route_table.public.id
}

# ─── ROUTE TABLE PRIVADA (sin NAT GW para ahorrar costos) ────
# Las subnets privadas sólo necesitan salida si tu ECS está en privadas.
# Como ECS usa IPs públicas aquí, la RT privada sólo conecta internamente.
resource "aws_route_table" "private" {
  vpc_id = aws_vpc.main.id

  tags = {
    Name = "${local.name}-rt-private"
  }
}

resource "aws_route_table_association" "private" {
  count          = length(aws_subnet.private)
  subnet_id      = aws_subnet.private[count.index].id
  route_table_id = aws_route_table.private.id
}
