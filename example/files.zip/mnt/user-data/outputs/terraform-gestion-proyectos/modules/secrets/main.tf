###############################################################
# MODULE: secrets
# Guarda los secretos de la aplicación en AWS Secrets Manager
###############################################################

locals {
  name = "${var.project_name}-${var.environment}"
}

resource "aws_secretsmanager_secret" "db_connection" {
  name                    = "${local.name}/db-connection-string"
  description             = "PostgreSQL connection string para ${local.name}"
  recovery_window_in_days = 0   # 0 = borrado inmediato (útil en dev/pruebas)

  tags = { Name = "${local.name}-db-secret" }
}

resource "aws_secretsmanager_secret_version" "db_connection" {
  secret_id     = aws_secretsmanager_secret.db_connection.id
  secret_string = var.db_connection_string
}

resource "aws_secretsmanager_secret" "jwt_key" {
  name                    = "${local.name}/jwt-key"
  description             = "JWT signing key para ${local.name}"
  recovery_window_in_days = 0

  tags = { Name = "${local.name}-jwt-secret" }
}

resource "aws_secretsmanager_secret_version" "jwt_key" {
  secret_id     = aws_secretsmanager_secret.jwt_key.id
  secret_string = var.jwt_key
}

resource "aws_secretsmanager_secret" "jwt_issuer" {
  name                    = "${local.name}/jwt-issuer"
  recovery_window_in_days = 0
}

resource "aws_secretsmanager_secret_version" "jwt_issuer" {
  secret_id     = aws_secretsmanager_secret.jwt_issuer.id
  secret_string = var.jwt_issuer
}

resource "aws_secretsmanager_secret" "jwt_audience" {
  name                    = "${local.name}/jwt-audience"
  recovery_window_in_days = 0
}

resource "aws_secretsmanager_secret_version" "jwt_audience" {
  secret_id     = aws_secretsmanager_secret.jwt_audience.id
  secret_string = var.jwt_audience
}

resource "aws_secretsmanager_secret" "s3_bucket_name" {
  name                    = "${local.name}/s3-bucket-name"
  recovery_window_in_days = 0
}

resource "aws_secretsmanager_secret_version" "s3_bucket_name" {
  secret_id     = aws_secretsmanager_secret.s3_bucket_name.id
  secret_string = var.s3_bucket_name
}
